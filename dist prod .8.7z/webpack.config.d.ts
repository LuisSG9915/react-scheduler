import HtmlWebpackPlugin = require("html-webpack-plugin");
export const mode: string;
export const entry: string;
export namespace output {
    const path: string;
    const filename: string;
}
export namespace module {
    const rules: {
        test: RegExp;
        exclude: RegExp;
        use: {
            loader: string;
        };
    }[];
}
export namespace resolve {
    const extensions: string[];
}
export const plugins: HtmlWebpackPlugin[];
export namespace devServer {
    const contentBase: string;
    const port: number;
}
