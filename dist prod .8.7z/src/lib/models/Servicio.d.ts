export interface Servicio {
    id: number;
    id_Cita: number;
    idServicio: number;
    descripcion: string;
    descripcion_corta: string;
    cantidad: number;
    precio: number;
    observaciones: string;
    tiempo: number;
    fechaCita: string;
    sucursal: number;
    idCliente: number;
    nombre: string;
    idEstilista: number;
    nombreEstilista: null;
    estatus: number;
    idColor: number;
}
export interface ServicioPost {
    id_Cita: number;
    idServicio: number;
    cantidad: number | null;
    precio: number;
    observaciones: string;
    usuario: number;
    d_servicio?: string;
    id?: number;
    tiempo?: number;
}
