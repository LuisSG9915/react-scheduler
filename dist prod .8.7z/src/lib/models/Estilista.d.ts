export interface Estilista {
    admin_id: number;
    title: string;
    mobile: string;
    avatar: string;
}
export interface EstilistaResponse {
    id: number;
    clave_empleado: string;
    status: number;
    d_estatus: string;
    nombre: string;
    fecha_nacimiento: string;
    sexo: string;
    RFC: string;
    CURP: string;
    imss: string;
    domicilio: string | null;
    colonia: string | null;
    poblacion: null | string;
    estado: null | string;
    lugar_nacimiento: null | string;
    codigo_postal: null | string;
    telefono1: null | string;
    telefono2: null | string;
    email: null | string;
    idDepartamento: number;
    descripcion_departamento: string;
    idPuesto: number;
    descripcion_puesto: string;
    observaciones: string;
    nivel_escolaridad: number;
    d_nivelEscolaridad: null | string;
    fecha_baja: null | string;
    motivo_baja: number | null;
    d_motiboBaja: null;
    motivo_baja_especificacion: null | string;
    fecha_alta: string;
    fecha_cambio: string;
    admin_id: number;
    title: string;
    mobile: string;
}
export declare enum Colonia {
    Empty = "",
    Q = "q"
}
export declare enum DEstatus {
    Ssacscscs = "ssacscscs"
}
export declare enum DescripcionDepartamento {
    Barrio = "Barrio",
    CDMexico = "Cd Mexico",
    SANPedro = "San Pedro"
}
export declare enum DescripcionPuesto {
    EstilistaLíder = "Estilista L\u00EDder",
    TeamManeger = "Team Maneger"
}
