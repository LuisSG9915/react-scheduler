import { Cliente } from "../models/Cliente";
export declare const useClientesWithUseEffect: () => {
    dataClientes: Cliente[];
    fetchClientes: () => Promise<void>;
    setDataClientes: import("react").Dispatch<import("react").SetStateAction<Cliente[]>>;
};
