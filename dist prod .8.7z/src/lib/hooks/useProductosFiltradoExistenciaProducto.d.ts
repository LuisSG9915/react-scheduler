import { ProductoExistencia } from "../models/Product";
interface Props {
    descripcion: string;
    inventariable: number;
    servicio: number;
    insumo: number;
    obsoleto: number;
    sucursal: number;
}
export declare const useProductosFiltradoExistenciaProducto: ({ descripcion, insumo, inventariable, obsoleto, servicio, sucursal, }: Props) => {
    dataProductos4: ProductoExistencia[];
    fetchProduct4: () => Promise<void>;
    setDataProductos4: import("react").Dispatch<import("react").SetStateAction<ProductoExistencia[]>>;
};
export {};
