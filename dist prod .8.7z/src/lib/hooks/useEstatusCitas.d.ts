export declare const useEstatusCitas: () => {
    estatusCitas: any[];
    fetchEstatusCitas: () => Promise<void>;
    setEstatusCitas: import("react").Dispatch<import("react").SetStateAction<any[]>>;
};
