declare const useStore: () => import("../store/types").Store;
export default useStore;
