interface Props {
    cveCliente: number;
}
export declare const useHistorialClientes: ({ cveCliente }: Props) => {
    historialClientes: any[];
    fetchEstatusCitas: () => Promise<void>;
    setHistorialClientes: import("react").Dispatch<import("react").SetStateAction<any[]>>;
};
export {};
