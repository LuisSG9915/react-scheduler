/**
 * The solution to make headers sticky with overflow
 */
declare const useSyncScroll: () => {
    headersRef: import("react").MutableRefObject<HTMLDivElement>;
    bodyRef: import("react").MutableRefObject<HTMLDivElement>;
};
export default useSyncScroll;
