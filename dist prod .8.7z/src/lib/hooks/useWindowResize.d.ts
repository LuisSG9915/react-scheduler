export declare function useWindowResize(): {
    width: number;
    height: number;
};
