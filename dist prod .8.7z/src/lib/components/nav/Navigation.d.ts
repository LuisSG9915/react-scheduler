export type View = "month" | "week" | "day";
declare const Navigation: () => JSX.Element;
export { Navigation };
