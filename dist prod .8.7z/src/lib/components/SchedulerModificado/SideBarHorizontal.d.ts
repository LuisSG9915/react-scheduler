declare const SidebarHorizontal: () => JSX.Element;
export default SidebarHorizontal;
