import React from "react";
interface Props {
    datah: any[];
    loadHistorialDetalle: (cveCliente: number, noVenta: number, idProducto: number, idSucursal: number) => Promise<void>;
    setParamsDetalles: (value: React.SetStateAction<{
        sucursal: number;
        numVenta: number;
        idProducto: number;
        clave: number;
        Cve_cliente: number;
        fecha: string;
    }>) => void;
    setIsModalOpen: (value: React.SetStateAction<boolean>) => void;
}
declare function TableHistorial({ datah, loadHistorialDetalle, setParamsDetalles, setIsModalOpen }: Props): JSX.Element;
export default TableHistorial;
