interface AuxProps {
    children: any;
}
declare const DateProvider: ({ children }: AuxProps) => JSX.Element;
export default DateProvider;
