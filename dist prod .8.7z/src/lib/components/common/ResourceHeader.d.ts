import { DefaultRecourse } from "../../types";
interface ResourceHeaderProps {
    resource: DefaultRecourse;
}
declare const ResourceHeader: ({ resource }: ResourceHeaderProps) => JSX.Element;
export { ResourceHeader };
