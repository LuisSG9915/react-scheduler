declare function SchedulerScreen(): JSX.Element;
export default SchedulerScreen;
