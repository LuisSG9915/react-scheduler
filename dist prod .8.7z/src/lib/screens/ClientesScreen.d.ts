declare function ClientesScreen(): JSX.Element;
export default ClientesScreen;
