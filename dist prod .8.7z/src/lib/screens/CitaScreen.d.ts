declare function CitaScreen(): JSX.Element;
export default CitaScreen;
