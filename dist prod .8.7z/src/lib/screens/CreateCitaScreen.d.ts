declare function CreateCitaScreen(): JSX.Element;
export default CreateCitaScreen;
