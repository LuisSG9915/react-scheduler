export declare const handleOpenVentas: (idCliente: number, nombreCliente: string) => void;
