import { ProcessedEvent } from "../types";
export declare const putCita: (cita: ProcessedEvent) => Promise<void>;
export declare const putCitaEstado: (event_id: any, fechaCita: any, idCliente: any, tiempo: any, admin_id: any, idUsuario: any, idEstatus: any, sucursal: any) => Promise<void>;
export declare const deleteCita: (id: number) => void;
export declare const getCitaServicios: (id: number) => Promise<any>;
export declare const peticionCita: () => Promise<any>;
