export declare const BORDER_HEIGHT = 1;
export declare const MULTI_DAY_EVENT_HEIGHT = 28;
export declare const MONTH_NUMBER_HEIGHT = 27;
export declare const COLOR_ESTATUS_CITAS: string[];
