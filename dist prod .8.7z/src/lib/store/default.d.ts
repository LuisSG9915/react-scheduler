import { SchedulerProps } from "../types";
export declare const defaultProps: (props: Partial<SchedulerProps>) => {
    height: number;
    navigation: boolean;
    selectedDate: Date;
    disableViewNavigator: boolean;
    events: any[] & import("../types").ProcessedEvent[];
    fields: any[] & import("../types").FieldProps[];
    loading: any;
    customEditor: any;
    onConfirm: any;
    onDelete: any;
    viewerExtraComponent: any;
    resources: any[] & import("../types").DefaultRecourse[];
    recourseHeaderComponent: any;
    resourceViewMode: "default" | "tabs";
    direction: "rtl" | "ltr";
    dialogMaxWidth: "xs" | "sm" | "md" | "lg" | "xl";
    locale: Locale;
    deletable: boolean;
    editable: boolean;
    hourFormat: "12" | "24";
    draggable: boolean;
    navigationPickerProps?: Partial<Omit<import("@mui/x-date-pickers").DateCalendarProps<Date>, "onClose" | "onChange" | "value" | "open" | "readOnly" | "openTo" | "views">>;
    eventRenderer?: (props: import("../types").EventRendererProps) => JSX.Element;
    getRemoteEvents?: (params: import("../types").ViewEvent) => Promise<void | import("../types").ProcessedEvent[]>;
    customViewer?: (event: import("../types").ProcessedEvent, close: () => void) => JSX.Element;
    viewerTitleComponent?: (event: import("../types").ProcessedEvent) => JSX.Element;
    timeZone?: string;
    onEventDrop?: (droppedOn: Date, updatedEvent: import("../types").ProcessedEvent, originalEvent: import("../types").ProcessedEvent) => Promise<void | import("../types").ProcessedEvent>;
    onEventClick?: (event: import("../types").ProcessedEvent) => void;
    onSelectedDateChange?: (date: Date) => void;
    onViewChange?: (view: import("../components/nav/Navigation").View) => void;
    translations: {
        moreEvents: string;
        loading: string;
        navigation: {
            month: string;
            week: string;
            day: string;
            today: string;
        } & Record<import("../components/nav/Navigation").View, string> & {
            today: string;
        };
        form: {
            addTitle: string;
            editTitle: string;
            confirm: string;
            delete: string;
            cancel: string;
        } & {
            addTitle: string;
            editTitle: string;
            confirm: string;
            delete: string;
            cancel: string;
        };
        event: {
            title: string;
            description: string;
            start: string;
            end: string;
            allDay: string;
        } & Record<string, string> & {
            title: string;
            description: string;
            start: string;
            end: string;
            allDay: string;
        };
    };
    resourceFields: {
        idField: string;
        textField: string;
        subTextField: string;
        avatarField: string;
        colorField: string;
    } & {
        idField: string;
        textField: string;
        subTextField?: string;
        avatarField?: string;
        colorField?: string;
    } & Record<string, string>;
    view: import("../components/nav/Navigation").View;
    month: {
        weekDays: number[];
        weekStartOn: number;
        startHour: number;
        endHour: number;
        navigation: boolean;
        disableGoToDay: boolean;
    } & import("../views/Month").MonthProps;
    week: {
        weekDays: number[];
        weekStartOn: number;
        startHour: number;
        endHour: number;
        step: number;
        navigation: boolean;
        disableGoToDay: boolean;
    } & import("../views/Week").WeekProps;
    day: {
        startHour: number;
        endHour: number;
        step: number;
        navigation: boolean;
    } & import("../views/Day").DayProps;
};
export declare const initialStore: {
    setProps: () => void;
    dialog: boolean;
    selectedRange: any;
    selectedEvent: any;
    selectedResource: any;
    handleState: () => void;
    getViews: () => any[];
    triggerDialog: () => void;
    triggerLoading: () => void;
    handleGotoDay: () => void;
    confirmEvent: () => void;
    onDrop: () => void;
    height: number;
    navigation: boolean;
    selectedDate: Date;
    disableViewNavigator: boolean;
    events: any[] & import("../types").ProcessedEvent[];
    fields: any[] & import("../types").FieldProps[];
    loading: any;
    customEditor: any;
    onConfirm: any;
    onDelete: any;
    viewerExtraComponent: any;
    resources: any[] & import("../types").DefaultRecourse[];
    recourseHeaderComponent: any;
    resourceViewMode: "default" | "tabs";
    direction: "rtl" | "ltr";
    dialogMaxWidth: "xs" | "sm" | "md" | "lg" | "xl";
    locale: Locale;
    deletable: boolean;
    editable: boolean;
    hourFormat: "12" | "24";
    draggable: boolean;
    navigationPickerProps?: Partial<Omit<import("@mui/x-date-pickers").DateCalendarProps<Date>, "onClose" | "onChange" | "value" | "open" | "readOnly" | "openTo" | "views">>;
    eventRenderer?: (props: import("../types").EventRendererProps) => JSX.Element;
    getRemoteEvents?: (params: import("../types").ViewEvent) => Promise<void | import("../types").ProcessedEvent[]>;
    customViewer?: (event: import("../types").ProcessedEvent, close: () => void) => JSX.Element;
    viewerTitleComponent?: (event: import("../types").ProcessedEvent) => JSX.Element;
    timeZone?: string;
    onEventDrop?: (droppedOn: Date, updatedEvent: import("../types").ProcessedEvent, originalEvent: import("../types").ProcessedEvent) => Promise<void | import("../types").ProcessedEvent>;
    onEventClick?: (event: import("../types").ProcessedEvent) => void;
    onSelectedDateChange?: (date: Date) => void;
    onViewChange?: (view: import("../components/nav/Navigation").View) => void;
    translations: {
        moreEvents: string;
        loading: string;
        navigation: {
            month: string;
            week: string;
            day: string;
            today: string;
        } & Record<import("../components/nav/Navigation").View, string> & {
            today: string;
        };
        form: {
            addTitle: string;
            editTitle: string;
            confirm: string;
            delete: string;
            cancel: string;
        } & {
            addTitle: string;
            editTitle: string;
            confirm: string;
            delete: string;
            cancel: string;
        };
        event: {
            title: string;
            description: string;
            start: string;
            end: string;
            allDay: string;
        } & Record<string, string> & {
            title: string;
            description: string;
            start: string;
            end: string;
            allDay: string;
        };
    };
    resourceFields: {
        idField: string;
        textField: string;
        subTextField: string;
        avatarField: string;
        colorField: string;
    } & {
        idField: string;
        textField: string;
        subTextField?: string;
        avatarField?: string;
        colorField?: string;
    } & Record<string, string>;
    view: import("../components/nav/Navigation").View;
    month: {
        weekDays: number[];
        weekStartOn: number;
        startHour: number;
        endHour: number;
        navigation: boolean;
        disableGoToDay: boolean;
    } & import("../views/Month").MonthProps;
    week: {
        weekDays: number[];
        weekStartOn: number;
        startHour: number;
        endHour: number;
        step: number;
        navigation: boolean;
        disableGoToDay: boolean;
    } & import("../views/Week").WeekProps;
    day: {
        startHour: number;
        endHour: number;
        step: number;
        navigation: boolean;
    } & import("../views/Day").DayProps;
};
