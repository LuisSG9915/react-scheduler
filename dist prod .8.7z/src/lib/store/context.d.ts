/// <reference types="react" />
import { Store } from "./types";
export declare const StoreContext: import("react").Context<Store>;
