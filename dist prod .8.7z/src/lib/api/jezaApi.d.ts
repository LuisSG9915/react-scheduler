export declare const jezaApi: import("axios").AxiosInstance;
