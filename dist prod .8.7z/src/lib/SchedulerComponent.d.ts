/// <reference types="react" />
import { SchedulerRef } from "./types";
declare const SchedulerComponent: import("react").ForwardRefExoticComponent<import("react").RefAttributes<SchedulerRef>>;
export default SchedulerComponent;
