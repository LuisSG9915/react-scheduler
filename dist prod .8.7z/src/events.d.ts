import { ProcessedEvent } from "./lib/types";
export declare const EVENTS: ProcessedEvent[];
export declare const RECOURCES: {
    admin_id: number;
    title: string;
    mobile: string;
    avatar: string;
    color: string;
}[];
