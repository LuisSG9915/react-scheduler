export declare const EVENTS: ({
    event_id: number;
    title: string;
    description: string;
    start: Date;
    end: Date;
    admin_id: number;
    color: string;
} | {
    event_id: number;
    title: string;
    start: Date;
    end: Date;
    admin_id: number;
    description?: undefined;
    color?: undefined;
})[];
export declare const RESOURCES: {
    admin_id: number;
    title: string;
    mobile: string;
    avatar: string;
}[];
