export default App;
declare function App(): import("react/jsx-runtime").JSX.Element;
