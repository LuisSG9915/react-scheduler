export default reportWebVitals;
declare function reportWebVitals(onPerfEntry: any): void;
